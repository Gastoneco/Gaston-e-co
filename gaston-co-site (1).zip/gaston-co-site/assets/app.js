// =============================
// Gaston&Co - Language + Active nav + Contact mailto
// =============================

const I18N = {
  it: {
    nav_home: "Home",
    nav_about: "Chi siamo",
    nav_wines: "Vini",
    nav_contact: "Contatti",
    hero_kicker: "Suvereto • Toscana • Edizione limitata",
    hero_title: "Il prestigio dei vini in edizione limitata",
    hero_sub: "Vini di nicchia dal cuore della Toscana, pensati per ristoranti ed enoteche che cercano carattere, eleganza e continuità.",
    hero_cta_primary: "Scopri i nostri vini",
    hero_cta_secondary: "Contatti & richieste",
    sec_values_title: "Per ristoratori ed enoteche",
    sec_values_sub: "Produzione familiare a Suvereto, cura maniacale dei dettagli e un’identità contemporanea che rispetta la tradizione.",
    v1_t: "Produzione limitata",
    v1_p: "Piccoli lotti, attenzione artigianale, massima coerenza bottiglia dopo bottiglia.",
    v2_t: "Stile distintivo",
    v2_p: "Un brand iconico e moderno, con un’anima storica e territoriale.",
    v3_t: "Pensati per la carta",
    v3_p: "Vini versatili e riconoscibili, perfetti per valorizzare abbinamenti e servizio.",
    sec_ig_title: "Seguici su Instagram",
    sec_ig_sub: "Novità, eventi e backstage dalla cantina. Feed integrabile con widget (vedi istruzioni in pagina).",
    btn_ig: "Apri Instagram",
    footer_right: "Gaston&Co. — Suvereto, Toscana",
    footer_left: "Edizioni limitate • Produzione familiare • Cura dei dettagli",
    about_title: "Chi siamo",
    about_sub: "Gaston&Co. nasce a Suvereto: una realtà familiare ambiziosa che unisce tradizione e sperimentazione con produzioni di nicchia.",
    about_placeholder: "Qui inseriremo la tua storia completa (me la dirai e la integriamo in modo perfetto, anche in EN).",
    wines_title: "I nostri vini",
    wines_sub: "Tre etichette, tre personalità. Produzione limitata: disponibile per ristoranti, enoteche e wine lovers esigenti.",
    wine_gastone_desc: "Rosso elegante e profondo. Struttura, energia e una beva che invita al secondo calice.",
    wine_anacleto_desc: "Bianco luminoso, sapido e mediterraneo. Freschezza e precisione al servizio della tavola.",
    wine_frou_desc: "Rosé raffinato e gastronomico: armonia, profumo e grande versatilità negli abbinamenti.",
    wine_cta: "Richiedi scheda / disponibilità",
    contact_title: "Contatti & richieste",
    contact_sub: "Scrivici liberamente: ogni richiesta verrà inoltrata a gastonecosrl@gmail.com.",
    form_name: "Nome",
    form_company: "Ristorante / Enoteca",
    form_email: "Email",
    form_phone: "Telefono",
    form_message: "Messaggio",
    form_send: "Invia richiesta",
    form_note: "Nota: su siti statici l’invio avviene via email (mailto). Se vuoi invio “automatico” senza client email, ti preparo integrazione Formspree/Netlify.",
    ig_embed_note_title: "Feed integrato",
    ig_embed_note: "Per un feed “a griglia” serve un widget (es. Elfsight/SnapWidget) o un embed dedicato. Inserisci il codice nella sezione indicata in pagina."
  },
  en: {
    nav_home: "Home",
    nav_about: "About",
    nav_wines: "Wines",
    nav_contact: "Contact",
    hero_kicker: "Suvereto • Tuscany • Limited edition",
    hero_title: "The Prestige of Limited-Edition Wines",
    hero_sub: "Boutique wines from the heart of Tuscany—crafted for restaurants and wine shops seeking character, elegance, and consistency.",
    hero_cta_primary: "Discover our wines",
    hero_cta_secondary: "Contacts & requests",
    sec_values_title: "For restaurants & wine shops",
    sec_values_sub: "Family-run production in Suvereto, obsessive attention to detail, and a contemporary identity rooted in tradition.",
    v1_t: "Limited production",
    v1_p: "Small batches, artisanal care, and consistent quality bottle after bottle.",
    v2_t: "Distinctive style",
    v2_p: "An iconic modern brand with a historic, territorial soul.",
    v3_t: "Made for wine lists",
    v3_p: "Versatile, recognizable wines—ideal for pairings and service.",
    sec_ig_title: "Follow us on Instagram",
    sec_ig_sub: "News, events, and behind-the-scenes from the cellar. The feed can be embedded via a widget (see notes on the page).",
    btn_ig: "Open Instagram",
    footer_right: "Gaston&Co. — Suvereto, Tuscany",
    footer_left: "Limited editions • Family-run • Detail-driven",
    about_title: "About us",
    about_sub: "Gaston&Co. was born in Suvereto: an ambitious family project blending tradition and experimentation with boutique releases.",
    about_placeholder: "We’ll place your full story here (send it to me and I’ll shape it perfectly—also in IT).",
    wines_title: "Our wines",
    wines_sub: "Three labels, three personalities. Limited production—available for restaurants, wine shops, and discerning wine lovers.",
    wine_gastone_desc: "An elegant, profound red. Structure, energy, and a drinkability that calls for a second glass.",
    wine_anacleto_desc: "A bright, savory Mediterranean white. Freshness and precision made for the table.",
    wine_frou_desc: "A refined, food-friendly rosé: harmony, aroma, and outstanding versatility.",
    wine_cta: "Request sheet / availability",
    contact_title: "Contact & requests",
    contact_sub: "Write freely—every request will be forwarded to gastonecosrl@gmail.com.",
    form_name: "Name",
    form_company: "Restaurant / Wine shop",
    form_email: "Email",
    form_phone: "Phone",
    form_message: "Message",
    form_send: "Send request",
    form_note: "Note: on static sites, sending happens via email (mailto). If you want true “automatic” sending, I can set up Formspree/Netlify.",
    ig_embed_note_title: "Embedded feed",
    ig_embed_note: "A grid feed requires a widget (e.g., Elfsight/SnapWidget) or a dedicated embed. Paste the code in the indicated section."
  }
};

function getLang(){
  return localStorage.getItem("gaston_lang") || "it";
}
function setLang(lang){
  localStorage.setItem("gaston_lang", lang);
  applyLang();
  setActiveLangButtons();
}

function applyLang(){
  const lang = getLang();
  document.documentElement.lang = lang;
  const dict = I18N[lang];
  document.querySelectorAll("[data-i18n]").forEach(el=>{
    const key = el.getAttribute("data-i18n");
    if(dict[key]) el.textContent = dict[key];
  });
}

function setActiveLangButtons(){
  const lang = getLang();
  document.querySelectorAll("[data-lang]").forEach(b=>{
    b.classList.toggle("active", b.getAttribute("data-lang") === lang);
  });
}

function setActiveNav(){
  const path = (location.pathname.split("/").pop() || "index.html").toLowerCase();
  document.querySelectorAll(".nav a").forEach(a=>{
    const href = (a.getAttribute("href") || "").toLowerCase();
    a.classList.toggle("active", href === path);
  });
}

function initMailtoForm(){
  const form = document.querySelector("#contactForm");
  if(!form) return;

  form.addEventListener("submit", (e)=>{
    e.preventDefault();

    const name = (form.querySelector("[name='name']").value || "").trim();
    const company = (form.querySelector("[name='company']").value || "").trim();
    const email = (form.querySelector("[name='email']").value || "").trim();
    const phone = (form.querySelector("[name='phone']").value || "").trim();
    const message = (form.querySelector("[name='message']").value || "").trim();

    const subject = encodeURIComponent(`Richiesta — ${company || name || "Gaston&Co"}`);
    const body = encodeURIComponent(
      `Nome: ${name}\n` +
      `Attività: ${company}\n` +
      `Email: ${email}\n` +
      `Telefono: ${phone}\n\n` +
      `Messaggio:\n${message}\n\n` +
      `---\nInviato dal sito Gaston&Co`
    );

    const to = "gastonecosrl@gmail.com";
    window.location.href = `mailto:${to}?subject=${subject}&body=${body}`;
  });
}

// Boot
document.addEventListener("DOMContentLoaded", ()=>{
  applyLang();
  setActiveLangButtons();
  setActiveNav();

  document.querySelectorAll("[data-lang]").forEach(btn=>{
    btn.addEventListener("click", ()=> setLang(btn.getAttribute("data-lang")));
  });

  initMailtoForm();
});
